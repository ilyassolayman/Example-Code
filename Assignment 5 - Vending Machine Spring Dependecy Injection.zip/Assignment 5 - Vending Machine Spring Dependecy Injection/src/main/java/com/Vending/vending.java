package com.Vending;

public interface vending {

    public int vend();

}
