import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Tests {

    @Test
    public void OnePoundChangeTest(){

        Change test = new Change(100);
        test.CalculateChange();
        int[] CorrectChange = {0,1,0,0,0,0,0,0};
        boolean Result = false;

        if (test.getOnePoundCoins() == CorrectChange[1]){
            Result = true;
        }

        if (test.getTwoPoundCoins() != CorrectChange[0]){
            Result = false;
        }

        else if (test.getFiftyPenceCoins() != CorrectChange[2]){
            Result = false;
        }

        else if (test.getTwentyPenceCoins() != CorrectChange[3]){
            Result = false;
        }

        else if (test.getTenPenceCoins() != CorrectChange[4]){
            Result = false;
        }

        else if (test.getFivePenceCoins() != CorrectChange[5]){
            Result = false;
        }
        else if (test.getTwoPenceCoins() != CorrectChange[6]){
            Result = false;
        }

        else if (test.getOnePenceCoins() != CorrectChange[7]){
            Result = false;
        }



        System.out.println(test.ReturnCoins());

        assertTrue(Result);
    }

    @Test
    public void OnePoundTwentyFourPenceTest(){
        Change test = new Change(124);
        test.CalculateChange();
        System.out.println(test.ReturnCoins());
        int[] CorrectChange = {0,1,0,1,0,0,2,0};
        boolean Result = false;

        if (test.getOnePoundCoins() == CorrectChange[1]){
            Result = true;
        }

        if (test.getTwoPoundCoins() != CorrectChange[0]){
            Result = false;
        }

        else if (test.getFiftyPenceCoins() != CorrectChange[2]){
            Result = false;
        }

        else if (test.getTwentyPenceCoins() != CorrectChange[3]){
            Result = false;
        }

        else if (test.getTenPenceCoins() != CorrectChange[4]){
            Result = false;
        }

        else if (test.getFivePenceCoins() != CorrectChange[5]){
            Result = false;
        }
        else if (test.getTwoPenceCoins() != CorrectChange[6]){
            Result = false;
        }

        else if (test.getOnePenceCoins() != CorrectChange[7]){
            Result = false;
        }



        System.out.println(test.ReturnCoins());

        assertTrue(Result);
    }

    @Test
    public void TenPoundFiftySevenPenceTest(){
        Change test = new Change(1057);
        test.CalculateChange();
        System.out.println(test.ReturnCoins());
        int[] CorrectChange = {5,0,1,0,0,1,1,0};
        boolean Result = false;

        if (test.getOnePoundCoins() == CorrectChange[1]){
            Result = true;
        }

        if (test.getTwoPoundCoins() != CorrectChange[0]){
            Result = false;
        }

        else if (test.getFiftyPenceCoins() != CorrectChange[2]){
            Result = false;
        }

        else if (test.getTwentyPenceCoins() != CorrectChange[3]){
            Result = false;
        }

        else if (test.getTenPenceCoins() != CorrectChange[4]){
            Result = false;
        }

        else if (test.getFivePenceCoins() != CorrectChange[5]){
            Result = false;
        }
        else if (test.getTwoPenceCoins() != CorrectChange[6]){
            Result = false;
        }

        else if (test.getOnePenceCoins() != CorrectChange[7]){
            Result = false;
        }



        System.out.println(test.ReturnCoins());

        assertTrue(Result);
    }

}
