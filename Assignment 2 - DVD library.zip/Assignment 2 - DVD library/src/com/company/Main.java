package com.company;

import java.io.FileReader;
import java.util.Locale;
import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        readInFile();


        boolean repeat = true;
        do {
            PrintMenu();
            Scanner in = new Scanner(System.in);
            int choice = Integer.parseInt(in.nextLine());

            switch (choice) {
                case 1:
                    add();
                    break;

                case 2:
                    remove();
                    break;

                case 3:
                    edit();
                    break;


                case 4:
                    DVD.listDVDs();
                    break;

                case 5:
                    display();
                    break;

                case 6:
                    System.out.println("Please enter the title of the film you are searching for");
                    String query = in.nextLine();
                    search(query);
                    break;

                case 7:
                    System.out.println("You've chosen to exit the DVD collection");
                    repeat = false;
                    break;

                default:
                    break;
            }

        } while (repeat);


        WriteOutFile();


    }//End of main

    public static void readInFile() {

        try {
            BufferedReader br = new BufferedReader(new FileReader("DVDs.txt"));

            String line;

            while ((line = br.readLine()) != null) {

                String[] elements = line.split(",");

                String title = elements[0];
                String date = elements[1];
                int rating = Integer.parseInt(elements[2]);
                String Director = elements[3];
                String studio = elements[4];
                String misc = elements[5];

                DVD Film = new DVD(title, date, rating, Director, studio, misc);
            }
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Welcome and thank you for using the DVD collection");
        System.out.println();

    }

    public static void PrintMenu() {

        System.out.println();
        System.out.println("1. Add a DVD to the collection");
        System.out.println("2. Remove a DVD from the collection");
        System.out.println("3. Edit the information for an existing DVD in the collection");
        System.out.println("4. List the DVDs in the collection");
        System.out.println("5. Display the information for a particular DVD");
        System.out.println("6. Search for DVD by title");
        System.out.println("7. Exit");
        System.out.println();
        System.out.println("Please enter a number : ");

    }

    public static void search(String query) {

        boolean found = false;
        for (int i = 0; i < DVD.Collection.size(); i++) {
            if (DVD.Collection.get(i).getTitle().toLowerCase().contains(query.toLowerCase())) {
                String s = DVD.Collection.get(i).getTitle();
                System.out.println();
                System.out.println("We have \"" + s + "\" in the collection. ID NUMBER : " + DVD.Collection.get(i).getId());
                found = true;
            }
        }

        if (found == false) {
            System.out.println("Sorry, \"" + query + "\" was not found in our collection");
        }

    }

    public static void add() {

        Scanner in = new Scanner(System.in);

        System.out.println("Please enter the title of the film : ");
        String newTitle = in.nextLine();

        System.out.println("Please enter the Release date of the film : ");
        String newDate = in.nextLine();

        System.out.println("Please enter the MPAA Rating of the film : ");
        int newRating = Integer.parseInt((in.nextLine()));

        System.out.println("Please enter the film Director's name : ");
        String newDirector = in.nextLine();

        System.out.println("Please enter the Studio that produced the film : ");
        String newStudio = in.nextLine();

        System.out.println("Please enter the some extra information about the film : ");
        String newMisc = in.nextLine();


        DVD film = new DVD(newTitle, newDate, newRating, newDirector, newStudio, newMisc);
    }

    public static void remove() {

        Scanner in = new Scanner(System.in);

        System.out.println("Please enter the ID of the film you would like to remove from the collection");
        System.out.println("If you would like to see all the IDs please enter 0 ");

        boolean run = true;
        int UserID;
        do {
            System.out.println("Enter ID : ");

            UserID = Integer.parseInt(in.nextLine());

            if (UserID == 0) {
                DVD.listDVDs(1);
            } else if (UserID > 0 & UserID < (DVD.Collection.get(DVD.Collection.size() - 1).getId() + 1)) run = false;


        } while (run);
        String title = null;


        for (int i = 0; i < DVD.Collection.size(); i++) {
            if (DVD.Collection.get(i).getId() == UserID) {
                title = DVD.Collection.get(i).getTitle();
                DVD.Collection.get(i).remove();
                System.out.println("Film ID " + UserID + ", \"" + title + "\", has been removed from the collection");
                break;
            }

        }
    }

    public static void edit(){

        Scanner in = new Scanner(System.in);

        System.out.println();
        System.out.println("Please enter the ID of the film you would like to edit in the collection");
        System.out.println("If you would like to see all the IDs please enter 0 ");

        boolean run = true;
        int UserID;
        do {
            System.out.println("Enter ID : ");

            UserID = Integer.parseInt(in.nextLine());

            if (UserID == 0) {
                DVD.listDVDs(1);
            } else if (UserID > 0 & UserID < (DVD.Collection.get(DVD.Collection.size() - 1).getId() + 1)) run = false;


        } while (run);

        int UserChoice = 1;

        DVD temp = null;
        for (int i = 0 ; i < DVD.Collection.size(); i++){
            if (UserID == DVD.Collection.get(i).getId()){
                temp = DVD.Collection.get(i);
                break;
            }
        }

        do{
            System.out.println();
            System.out.println("1. TITLE\t2. RELEASE DATE\t\t3. MPAA RATING\t\t4.DIRECTOR'S NAME\t5.STUDIO\t6.NOTE");
            System.out.println("Please the number of the field you'd like to edit");
            System.out.println("Enter 0 to stop editing this film: ");
            UserChoice = Integer.parseInt(in.nextLine());

            switch(UserChoice){
                case 1:
                    System.out.println();
                    System.out.println("Enter New Title: ");
                    String title = in.nextLine();
                    temp.setTitle(title);
                    break;

                case 2:
                    System.out.println();
                    System.out.println("Enter New Release Date : ");
                    String date = in.nextLine();
                    temp.setReleaseDate(date);
                    break;

                case 3:
                    System.out.println();
                    System.out.println("Enter New MPAA Rating : ");
                    int rating = Integer.parseInt(in.nextLine());
                    temp.setRating(rating);
                    break;
                case 4:
                    System.out.println();
                    System.out.println("Enter New Director's Name : ");
                    String director = in.nextLine();
                    temp.setDirectorsName(director);
                    break;
                case 5:
                    System.out.println();
                    System.out.println("Enter New Studio : ");
                    String studio = in.nextLine();
                    temp.setStudio(studio);
                    break;
                case 6:
                    System.out.println();
                    System.out.println("Enter New Note : ");
                    String note = in.nextLine();
                    temp.setMisc(note);
                    break;
                case 0:
                    System.out.println("Thanks for editing, now you've finished editing " + temp.getTitle());
                    break;
                default:
                    break;
            }

        }while(UserChoice!= 0);



    }

    public static int display(){

        Scanner in = new Scanner(System.in);

        System.out.println();
        System.out.println("Please enter the ID of the film you would like to display information for");
        System.out.println("If you would like to see all the IDs please enter 0 ");

        boolean run = true;
        int UserID;
        do {
            System.out.println("Enter ID : ");

            UserID = Integer.parseInt(in.nextLine());

            if (UserID == 0) {
                DVD.listDVDs(1);
            } else if (UserID > 0 & UserID < (DVD.Collection.get(DVD.Collection.size() - 1).getId() + 1)) run = false;


        } while (run);

        DVD temp = null;
        for (int i = 0 ; i < DVD.Collection.size(); i++){
            if (UserID == DVD.Collection.get(i).getId()){
                temp = DVD.Collection.get(i);
                break;
            }
        }

        if (temp == null){
            System.out.println("There is no DVD in our collection with that ID");
            System.out.println();
            return -1;
        }

        System.out.println();
        System.out.println("TITLE : " + temp.getTitle());
        System.out.println("RELEASE DATE : " + temp.getReleaseDate());
        System.out.println("MPAA RATING : " + temp.getRating());
        System.out.println("DIRECTOR : " + temp.getDirectorsName());
        System.out.println("STUDIO : " + temp.getStudio());
        System.out.println("NOTE : " + temp.getMisc());
        System.out.println();

        return 0;
    }

    public static void WriteOutFile(){
        System.out.println("Thank you for using the DVD collection, have a good day ! ");
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter("DVDs.txt"));

            for (int i = 0; i < DVD.Collection.size(); i++){
                DVD temp = DVD.Collection.get(i);
                bw.write(temp.getTitle()+",");
                bw.write(temp.getReleaseDate()+",");
                bw.write(temp.getRating()+",");
                bw.write(temp.getDirectorsName()+",");
                bw.write(temp.getStudio()+",");
                bw.write(temp.getMisc()+"\n");
            }
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }//End of WriteOutFile method


}//End of main class
