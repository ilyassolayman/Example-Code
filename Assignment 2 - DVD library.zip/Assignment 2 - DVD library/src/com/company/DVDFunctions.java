package com.company;

public interface DVDFunctions {

    public void remove();


}
