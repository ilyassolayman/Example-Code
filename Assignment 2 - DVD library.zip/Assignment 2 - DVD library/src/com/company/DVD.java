package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class DVD implements DVDFunctions {

    private String title;
    private String ReleaseDate;
    private int rating;
    private String DirectorsName;
    private String studio;
    private String misc;
    private int id;
    public static ArrayList<DVD> Collection = new ArrayList<>();
    public static int noDVDs = 0;


    public DVD(String title, String releaseDate, int rating, String directorsName, String studio, String misc) {
        this.title = title;
        this.ReleaseDate = releaseDate;
        this.rating = rating;
        this.DirectorsName = directorsName;
        this.studio = studio;
        this.misc = misc;
        Collection.add(this);
        this.id = ++noDVDs;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReleaseDate() {
        return ReleaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        ReleaseDate = releaseDate;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getDirectorsName() {
        return DirectorsName;
    }

    public void setDirectorsName(String directorsName) {
        DirectorsName = directorsName;
    }

    public String getStudio() {
        return studio;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public String getMisc() {
        return misc;
    }

    public void setMisc(String misc) {
        this.misc = misc;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "DVD{" +
                "title='" + title + '\'' +
                ", ReleaseDate='" + ReleaseDate + '\'' +
                ", rating=" + rating +
                ", DirectorsName='" + DirectorsName + '\'' +
                ", studio='" + studio + '\'' +
                ", misc='" + misc + '\'' +
                ", id=" + id +
                '}';
    }



    @Override
    public void remove() {

        for(int i = 0; i < Collection.size(); i++){
            if (Collection.get(i).getId() == this.id){
                Collection.remove(i);
            }
        }
    }


    public static void listDVDs(){
        System.out.println("\t\t\t\tLIST OF DVDs IN THE COLLECTION");

        System.out.println("Title");
        System.out.println();
        for(int i = 0; i < Collection.size(); i++){
            System.out.println(Collection.get(i).getTitle());
        }
    }

    public static void listDVDs(int x){
        System.out.println("\t\t\t\tLIST OF DVDs IN THE COLLECTION WITH ID NUMBERS ");


        System.out.println();
        for(int i = 0; i < Collection.size(); i++){
            System.out.println("TITLE : " + Collection.get(i).getTitle());
            System.out.println("ID : "+Collection.get(i).getId());
            System.out.println();
        }
    }
}//End of DVD class
