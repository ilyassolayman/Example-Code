package com.company;

import java.util.Scanner;
import java.util.Arrays;


public class Main {

    public static void main(String[] args) {

        //Q1 RockPaperScissors

        final int ROCK = 1, PAPER = 2, SCISSORS = 3;
        String choices[] = {"ROCK", "PAPER", "SCISSORS"};
        boolean play = true;
        Scanner input = new Scanner(System.in);
        System.out.println("WELCOME TO ROCK PAPER SCISSORS !!!");
        System.out.println("You are playing against a computer");
        System.out.println();

        do{ // Do while loop to encapsulate the main body of this question and allow user to play game again

            System.out.println("How many rounds of rock paper scissors would you like to play ? :");
            int user_rounds = input.nextInt(); // Asking the user how many rounds they want to play

            if (user_rounds < 1 || user_rounds > 10){ //If the user inputs play a number of rounds outside the range, quit programme
                System.out.println("ERROR : INVALID INPUT");
                System.out.println("THANK YOU AND GOODBYE");
                System.exit(0);
            }

            else{ //If the number of rounds user wants to play is valid, play a game of Rock paper scissors

                int ties = 0, user_wins = 0, computer_wins =0; //Tracking the round wins

                for (int i = 0; i < user_rounds; i++){ // For loop that allows user to play the selected number of rounds

                    System.out.println("ROCK = 1 \t PAPER = 2 \t SCISSORS = 3");
                    System.out.println();
                    System.out.println("Please enter your choice 1, 2 or 3 : ");
                    int user_choice = input.nextInt();
                    int computer_choice = (int) (Math.random()*3 + 1); //Generating computer choice 1, 2 or 3
                    System.out.println(); //Line below outputs the user the choices of the user and computer
                    System.out.println("USER CHOICE : " + choices[user_choice - 1] + "\t & \tCOMPUTER CHOICE : " + choices[computer_choice - 1] );
                    System.out.println();
                    if (user_choice == computer_choice){ //If the computer and user make the same choice, its a tie
                        System.out.println("***********************");
                        System.out.println("\t   ITS A TIE");
                        System.out.println("***********************");
                        System.out.println();
                        ties++;
                    }

                    else{
                        switch (computer_choice){ //Evaluation of round depending on the different choices of the computer and user
                            case 1 :
                                if (user_choice == PAPER ){
                                    System.out.println("***********************");
                                    System.out.println("USER WINS THIS ROUND!");
                                    System.out.println("***********************");
                                    System.out.println();
                                    user_wins++;
                                }
                                else{ //else used here instead of else if - assume some user competency so they input 1 2 or 3
                                    System.out.println("***********************");
                                    System.out.println("COMPUTER WINS THIS ROUND!");
                                    System.out.println("***********************");
                                    System.out.println();
                                    computer_wins++;
                                }
                                break;

                            case 2 :
                                if (user_choice == SCISSORS ){
                                    System.out.println("***********************");
                                    System.out.println("USER WINS THIS ROUND!");
                                    System.out.println("***********************");
                                    System.out.println();
                                    user_wins++;
                                }
                                else{
                                    System.out.println("***********************");
                                    System.out.println("COMPUTER WINS THIS ROUND!");
                                    System.out.println("***********************");
                                    System.out.println();
                                    computer_wins++;
                                }
                                break;

                            case 3 :
                                if (user_choice == ROCK ){
                                    System.out.println("***********************");
                                    System.out.println("USER WINS THIS ROUND!");
                                    System.out.println("***********************");
                                    System.out.println();
                                    user_wins++;
                                }
                                else{
                                    System.out.println("************************");
                                    System.out.println("COMPUTER WINS THIS ROUND!");
                                    System.out.println("************************");
                                    System.out.println();
                                    computer_wins++;
                                }
                                break;

                            default:
                                break;
                        }//End of switch statement

                    }//End of else statement for round evaluation

                }//End of game for loop

                //Body of code that outputs the rounds won and by whom
                System.out.println();
                System.out.println();
                System.out.println("----------------------------------------");
                System.out.println("Rounds won by user : " + user_wins  );
                System.out.println("Rounds won by computer : " + computer_wins );
                System.out.println("Rounds tied : " + ties  );
                System.out.println("----------------------------------------");
                System.out.println();

                //Outputting who won this game of Rock Paper Scissors
                if (user_wins == computer_wins){
                    System.out.println("There is no winner : You have tied with the computer this game");
                }
                else if (user_wins > computer_wins){
                    System.out.println("The user has won this game!!");
                }

                else{
                    System.out.println("The computer has won this game!!");
                }

                //Ask the user if they would like to play again
                System.out.println();
                System.out.println();
                System.out.println("Would you like to play again ?");
                System.out.println("Enter 1 for yes or 0 for no");
                System.out.println("ENTER CHOICE : ");
                int play_choice = input.nextInt();


                //Update boolean variable play which breaks or allows the next iteration of this loop
                //Based on whether the user wants to play again
                if (play_choice == 1){

                }
                else{
                    System.out.println();
                    System.out.println("Thank you for playing and have a nice day!");
                    play = false;
                }



            }//End of else for game evaluation

        }while(play == true);

        //End of game and user no longer wants to play when we break out of this loop


        //END OF Q1




        //Uncomment the block comments on the questions to test them
/*

        //Q2
        Scanner input = new Scanner(System.in);
        System.out.println("What is the name of your dog ? ");
        String name_of_dog = input.nextLine();
        DogGenetics(name_of_dog);
*/


/*
        //Q3
        Scanner input = new Scanner(System.in); //Set up scanner object to allow for user input
        System.out.println("What is your age : ");
        int age = input.nextInt(); //Ask user for input and store the input in age

        HealthyHearts(age); //Call HealthyHearts method passing the age inputted from user
*/


/*
        //Q4
        int[] numbers = {999, -60, -77, 14, 160, 301 };
        SummativeSums(numbers);
*/

    }//End of main


    public static void DogGenetics(String dog_name){

        System.out.println("Well then, I have this highly reliable report on " + dog_name + "'s prestigious background right here.");
        System.out.println();

        int percentage_counter = 0;
        int[] percentages = new int[5];
        String[] breeds = {"Golden Retriever","Bulldog","English Mastiff","German Shepherd","Rottweiler"};

        for (int i = 0; i < 4; i++ ){

            int fraction = (int)(Math.random()*(100-percentage_counter));

            percentages[i] = fraction;
            percentage_counter += fraction;
        }

        percentages[4] = 100-percentage_counter;

        System.out.println(dog_name + " is :" );
        System.out.println();

        for (int i = 0; i < 5; i++){
            System.out.println(percentages[i] + "% " + breeds[i]);
        }
        System.out.println();




    }

    public static void HealthyHearts(int age){

        int maximum_bpm = 220 - age;
        double lower_bpm = (double)(maximum_bpm)*0.5; // Calculating 50% and 85% the maximum heart rate
        double upper_bpm = (double)(maximum_bpm)*0.85;

        int Lower_bpm = (int)Math.round(lower_bpm); // Rounding the calculated upper and lower bounds as beats are integer values
        int Upper_bpm = (int)Math.round(upper_bpm);


        System.out.println("Your maximum heart rate should be "  + maximum_bpm + " beats per minute");
        System.out.println("Your target HR Zone is " +  Lower_bpm + " - " + Upper_bpm + "  beats per minute");


    }

    public static void SummativeSums(int [] array){

        int sum = 0;

        for (int i = 0; i < array.length; i++){

            sum = sum + array[i];
        }

        System.out.println("Array sum : " + sum);


    }
}//End of class
