from scipy.integrate import odeint, trapz
import matplotlib.pyplot as plt
import scipy.optimize as opt
import numpy as np

BAR = 1.0546e-34
MASS = 9.1094e-31
e_el = 1.6022e-19
RADIUS = 5.2918e-11

def eqn(y, x, energy):
    cond = y[0]
    func_1 = y[1]
    func_2 = -energy*cond*((MASS*2)/BAR**2)
    array = np.array([func_1, func_2])
    return array

def solve(energy, func):
    t = np.linspace(0, RADIUS, 1000)
    ans = odeint(func, [0, 1], t, args=(energy, ))
    return ans[-1, 0]

BI = opt.bisect(solve, 133*e_el, 135*e_el, xtol=e_el*1e-4, args=(eqn,))/(e_el)
print("The ground state energy for the infinite potential well is %s eV"%round(BI, 3))

########################################################################
def eqn2(y, x, energy, v, a):
    cond = y[0]
    func_1 = y[1]
    func_2 = -((2 * MASS) / BAR**2)*(energy*cond-v*((x**2)/(a**2)) * cond)
    array = np.array([func_1, func_2])
    return array

def solve2(energy, func):
    a = 1e-11
    t = np.linspace(a*(-10), a*10, 1000)
    V = e_el*50
    answer = odeint(func, [0, 1], t, args=(energy, V, a))
    return answer[-1, 0]

start = 1
end = 940
data = 200
y_axis = np.array([])
x_axis = np.linspace(start, end, data)
y_axis = np.array([])
for x in x_axis:
    S = solve2(x*e_el, eqn2)
    y_axis = np.append(y_axis, S)


index = 0
array = np.array([])
while index < (data - 1):
    nu1 = np.sign(y_axis[index])
    nu2 = np.sign(y_axis[index + 1])
    if nu1 != nu2:
        array = np.append(array, x_axis[index])
    index += 1

P = np.array([])
for element in array:
    P = np.append(P, opt.bisect(solve2, (element-3)*e_el, (element+3)*e_el, xtol=e_el*1e-3, args=(eqn2,))/e_el)

print("\nGround state energy for finite potential well: %s eV" %(round(P[0], 2)))
print("1st excited energy state is : %s eV" %(round(P[1], 2)))
print("2nd excited energy state is : %s eV\n" %(round(P[2], 2)))
differences = np.diff(P)

def result():
    return differences

print("The energy difference between n0 and n1 states is %s eV" %(round(differences[0], 2)))
print("The energy difference between n1 and n2 states is also %s eV" %(round(differences[1], 2)))

def solve3(energy, x):
    V = 50*e_el
    a = 1e-11
    ans = odeint(eqn2, [0, 1], x, args=(energy, V, a))
    val = ans[:, 0]
    return val

count = 0
a = 1e-11
b = -10*a
l = 1000
dx = (20 * a) / l
Z = np.linspace(b, -b, l)

for x in P[0:3]:
    wave = solve3(x*e_el, Z)
    wavesq = np.power(wave, 2)
    wavesqint = trapz(wavesq)
    wavenorm = wave/np.sqrt(wavesqint)

    plt.plot((Z/a)[250:750], (wavenorm)[250:750], label='n%s = %s eV' %(count, round(x, 2)))
    plt.legend(loc='lower left')
    plt.title('Normalised Wavefunctions')
    plt.xlabel('x (a)', fontsize=15)
    plt.ylabel('|\u03C8(x)|²', fontsize=16)
    plt.axhline(0, color='black')
    plt.axvline(0, color='black')

    count += 1