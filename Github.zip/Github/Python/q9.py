from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt

def differential(init, time, mu):
    condition = init[0]
    r = np.sqrt((condition+mu)**2+init[2]**2)
    s = np.sqrt((condition+mu-1)**2+(init[2])**2)
    dx = init[1]
    dy = init[3]
    d2x = condition + init[3]*2-((1-mu)*(condition + mu)/r**3)-(mu*(condition-1+mu)/s**3)
    d2y = init[2] - 2*init[1] - (((1-mu)*init[2])/r**3) - (mu*init[2]/s**3)
    array = np.array([dx, d2x, dy, d2y])
    return array

def satellite(init, time, mu):
    solutions = odeint(differential, init, time, args=(mu, ))
    return solutions

def main():
    mu = 0.01227471
    time = np.linspace(0, 18, 200)
    init = np.array([0.994, 0.0, 0.0, -2.0015851])
    answer = satellite(init, time, mu)

    plt.figure(figsize=(15, 15), linewidth=6, edgecolor="black")
    plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=1, hspace=3)
    plt.subplot(231)
    plt.title(' Tracectory of y(t) against x(t)')
    plt.xlabel('x(t)')
    plt.ylabel('y(t)')
    plt.plot(answer[:200, 0], answer[:200, 2])
    plt.subplot(232)

    plt.title('x(t) and y(t) against time')
    plt.ylabel('x and y solutions')
    plt.xlabel('Time')
    plt.plot(time, answer[:200, 2], 'red', label='y(t) solution')
    plt.plot(time, answer[:200, 0], 'blue', label='x(t) solution')
    plt.legend(loc='upper right')
    plt.subplot(233)
    plt.title('Speed')
    plt.xlabel('Speed in x')
    plt.ylabel('Speed in y')
    plt.plot(answer[:, 1], answer[:, 3], 'purple')
    plt.show()
main()