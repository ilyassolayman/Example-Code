from math import atan2
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

def differentials(y, t):
    condition = y[0]
    function_0 = y[1]
    function_1 = (-2 )*(y[2]**2)*condition*(1 -(condition**2))*np.exp(-((condition**2)+(y[2]**2)))
    function_2 = y[3]
    function_3 = (-2) * (condition**2)*y[2]*(1-(y[2]**2))*np.exp(-((condition**2)+(y[2]**2)))
    array = np.array([function_0, function_1, function_2, function_3])
    return array

def odeintf(init, time):
    return odeint(differentials, init, time)

def trajectory(impactar, speed):
    vx = 0
    x = impactar
    y = -2
    vy0 = speed
    init = np.array([x, vx, y, vy0])
    time = np.linspace(0, 10/vy0, 300)
    answer = odeintf(init, time)
    solution = [answer[:, 0], answer[:, 2]]
    return solution

def plot_1():
    impact = np.random.normal(0.15, 0.2)
    vy = np.random.uniform(0, 0.5)
    x_axis, y_axis = trajectory(impact, vy)
    plt.plot(x_axis, y_axis, 'blue')
    plt.xlabel('x(t)', fontsize=16)
    plt.ylabel('y(t)', fontsize=16)
    plt.title('Trajectory for impactpar = %s and vy = %s'%(round(impact, 3),
                                                     round(vy, 3)), fontsize=14)
    plt.show()




def scatterangles(allb, speed):
    vx = 0
    _ = allb
    y = -2
    vy = speed
    cte = 10/vy
    time = np.linspace(0, cte, 300)
    angle = np.array([])
    for element in allb:
        init = np.array([element, vx, y, vy])
        ans = odeintf(init, time)
        angle = np.append(angle, atan2(ans[299, 3], ans[299, 1]))
    return angle

def plot_2():
    x_axis = np.linspace(-0.2, 0.2, 400)
    y_axis = scatterangles(x_axis, 0.1)
    plt.plot(x_axis, y_axis, 'red')
    plt.xlabel('Impact Paramater')
    plt.ylabel('Scatter angle')
    plt.title('Scattering dependance on impact parameters', fontsize=15)
    plt.show()

plot_2()