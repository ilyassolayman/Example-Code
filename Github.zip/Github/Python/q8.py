from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt

def functions(initial, time, k1, k2):
    cte = [k1, k2]
    dy1 = -cte[0] * initial[0]
    dy2 = cte[0]*initial[0] - cte[1]*initial[1]
    array = np.array([dy1, dy2])
    return array

def rateEqns(initial, time, k1, k2):
    cte = [k1, k2]
    solution = odeint(functions, initial, time, args=(cte[0], cte[1]))
    return solution

def main():
    y = [100, 0]
    initial = np.array([y[0], y[1]])
    condition = initial[0]
    cte = [0.2, 0.8]
    time = np.linspace(0, 20, 40)
    solution = rateEqns(initial, time, cte[0], cte[1])
    Loss = condition - solution[:, 0] - solution[:, 1]
    print(Loss[10])

    plt.plot(time, solution[:40, 0], 'g+')
    plt.plot(time, solution[:40, 1], 'r-')
    plt.title("Solution to Ordinary Differential Equation")
    plt.xlabel('Time')
    plt.ylabel('y(t)')
    plt.show()

    plt.title('Loss Feed plot')
    plt.xlabel('Time')
    plt.ylabel('Loss feed')
    plt.plot(time, Loss, 'purple')
    plt.show()

main()