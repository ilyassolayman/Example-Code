#include <iostream>
#include <string>
#include <vector>
#include <algorithm>


std::string translate(std::string);

int main()
{
  std::string charsss = "hello, secret meeting tonight.";

  translate(charsss);
  return 0;

}

std::string translate(std::string text){

  std::string translation;

  for (int i = 0 ; i < text.size() ; i++){

    char X = text[i];
    char Y = text[i-1];

    if ( int(X) == 97 || int(X) == 101 || int(X) == 105 || int(X) == 111 || int(X) == 117){

      if (i == 0){
        translation += text[0];
      }

      else if ( int(Y) == 97 || int(Y) == 101 || int(Y) == 105 || int(Y) == 111 || int(Y) == 117 ){

        translation += X;

      }

      else{
        translation += "av";
        translation += X;
      }


    }

    else {
      translation += X;
    }

  }

  std::cout << translation << std::endl;


  return "";
}
