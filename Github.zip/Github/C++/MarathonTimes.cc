#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

int main()
{

  int n;

  std::cin >> n;

  std::vector<std::string> times;
  std::vector<int> times_seconds;


  for (int i = 0; i < n; i++)
  {
    std::string time;
    std::cin >> time;
    times.push_back(time);
  }

  for (int i = 0; i < n; i++)
  {

    std::string hour = times[i].substr(0,2);
    std::string minutes = times[i].substr(3,2);
    std::string seconds_string = times[i].substr(6,2);

    int hour_seconds = std::stoi(hour)*3600;
    int minutes_seconds = std::stoi(minutes)*60;
    int seconds = std::stoi(seconds_string);

    times_seconds.push_back(hour_seconds+minutes_seconds+seconds);

  }

  int min_time_index = std::min_element(times_seconds.begin(), times_seconds.end()) - times_seconds.begin();

  std::cout << times[min_time_index];





  return 0;

}
