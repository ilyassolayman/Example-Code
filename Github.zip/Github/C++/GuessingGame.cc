#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <vector>


void play_game();
void print_vector(std::vector<int>, int);

int main()
{

  srand(time(NULL)); // srand() Seeds our random number once when the application runs. The seed is time(NULL) which changes everytime we run the application as it runs off of the time of the system clock.
  int choice;

  std::cout<<"Welcome to the game menu. Please select one of the following options : \n" << std::endl;

  do
  {

    std::cout << "\n0. Quit menu" << std::endl;
    std::cout << "1. Play guessing game" << std::endl;
    std::cout << std::endl;
    std::cin >> choice ;


    switch (choice)
    {

      case 0:
      std::cout << std::endl;
      std::cout << "You have chosen to quit the main menu. Thank you for playing\n\n";
      break;

      case 1:
      play_game();
      break;

      default:
      break;


    }



  }
  while(choice != 0);





  return 0;
}

void play_game()
{

  std::vector<int> guesses;
  std::vector<int> inputs;
  int tries = 0;


  int random = rand() % 251; //Generates a random number between 0 and 250 inclusive using the modulus (remainder) operator
  std::cout << "\n\nThe guessing game is being played. Guess a number between 0 and 251\n";

  std::cout << "Guess a number : ";

  while(true)
  {

    int guess;
    std::cin>>guess;
    bool statement = false;


    for (int i = 0; i < tries ;i++)
    {

      if (inputs[i] == guess)
      {
        statement = true;
        break;
      }

    }



    if (guess == random)
    {
      guesses.push_back(guess);
      std::cout << std::endl;
      std::cout << "Congratulations, " << random << " is the right number!\n\n\n";
      break;
    }

    else if (statement == true)
    {
      std::cout << "You have already guessed this number before, try a different number!\n";
    }

    else if (guess < random)
    {
      std::cout << "Too low! Guess again\n";
      guesses.push_back(guess);
      inputs.push_back(guess);

    }
    else
    {
      std::cout << "Too high! Try again\n";
      guesses.push_back(guess);
      inputs.push_back(guess);

    }
    tries++;


  }

  print_vector(guesses, tries);


}

void print_vector(std::vector<int> array, int tries)
{


    std::cout << "You guessed the correct answer within " << tries + 1 << " guesses, with " << array.size() << " unique guesses\n";
    std::cout << "This was your sequence of unique guesses : \n";

    for (int j = 0; j < array.size(); j++)
    {

      std::cout << array[j] << "\t";

    }

    std::cout << "\n\n" ;

}
