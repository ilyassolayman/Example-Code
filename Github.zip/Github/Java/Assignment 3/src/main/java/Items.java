import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Items implements vending{

    private String name;
    private int price;
    private int stock;
    private int ItemID;
    public static ArrayList<Items> Collection = new ArrayList<>();
    public static ArrayList<Items> AvailableItems = new ArrayList<>();
    public static int NoItems = 0;

    public Items(String name, int price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.ItemID = ++NoItems;
        Collection.add(this);

        Stream<Items> I = Collection.stream().filter((p) -> p.getStock() > 0);
        AvailableItems = (ArrayList<Items>) I.collect(Collectors.toList());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getItemID() {
        return ItemID;
    }

    public void setItemID(int itemID) {
        ItemID = itemID;
    }

    @Override
    public String toString() {
        return "Items{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                '}';
    }


    @Override
    public int vend() {
        if ( this.stock == 0){
            System.out.println("THIS ITEM CANNOT BE VENDED");
            return -1;
        }
        else{
            this.stock--;
            Stream<Items> I = Collection.stream().filter((p) -> p.getStock() > 0);
            AvailableItems = (ArrayList<Items>) I.collect(Collectors.toList());
            return 0;
        }
    }

    public static void PrintItems(){

        System.out.print("ITEM\t\t\tPRICE\t\t\tID");
        System.out.println();
        for(int i = 0 ; i < AvailableItems.size(); i++){
            if(AvailableItems.get(i).getStock()!= 0){
                System.out.print(AvailableItems.get(i).getName() + "\t\t\t");
                System.out.print("£" + (double) (AvailableItems.get(i).getPrice()/100.0) + "\t\t\t");
                System.out.println(AvailableItems.get(i).getItemID() + "\t\t\t");
            }
        }

        System.out.println();
        //System.out.println("Enter 0 to quit");


    }//End of PrintItems() method
}
