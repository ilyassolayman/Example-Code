import java.math.BigDecimal;

public class Change {

    private int ChangeDue;
    private int TwoPoundCoins;
    private int OnePoundCoins;
    private int FiftyPenceCoins;
    private int TwentyPenceCoins;
    private int TenPenceCoins;
    private int FivePenceCoins;
    private int TwoPenceCoins;
    private int OnePenceCoins;
    private BigDecimal change = new BigDecimal(ChangeDue);



    public Change(){};

    public Change(int difference){this.ChangeDue = difference;}

    public int getChangeDue() {
        return ChangeDue;
    }

    public void setChangeDue(int changeDue) {
        ChangeDue = changeDue;
    }

    public int getTwoPoundCoins() {
        return TwoPoundCoins;
    }

    public void setTwoPoundCoins(int twoPoundCoins) {
        TwoPoundCoins = twoPoundCoins;
    }

    public int getOnePoundCoins() {
        return OnePoundCoins;
    }

    public void setOnePoundCoins(int onePoundCoins) {
        OnePoundCoins = onePoundCoins;
    }

    public int getFiftyPenceCoins() {
        return FiftyPenceCoins;
    }

    public void setFiftyPenceCoins(int fiftyPenceCoins) {
        FiftyPenceCoins = fiftyPenceCoins;
    }

    public int getTwentyPenceCoins() {
        return TwentyPenceCoins;
    }

    public void setTwentyPenceCoins(int twentyPenceCoins) {
        TwentyPenceCoins = twentyPenceCoins;
    }

    public int getTenPenceCoins() {
        return TenPenceCoins;
    }

    public void setTenPenceCoins(int tenPenceCoins) {
        TenPenceCoins = tenPenceCoins;
    }

    public int getFivePenceCoins() {
        return FivePenceCoins;
    }

    public void setFivePenceCoins(int fivePenceCoins) {
        FivePenceCoins = fivePenceCoins;
    }

    public int getTwoPenceCoins() {
        return TwoPenceCoins;
    }

    public void setTwoPenceCoins(int twoPenceCoins) {
        TwoPenceCoins = twoPenceCoins;
    }

    public int getOnePenceCoins() {
        return OnePenceCoins;
    }

    public void setOnePenceCoins(int onePenceCoins) {
        OnePenceCoins = onePenceCoins;
    }

    @Override
    public String toString() {
        return "Change{" +
                "ChangeDue=" + ChangeDue +
                ", TwoPoundCoins=" + TwoPoundCoins +
                ", OnePoundCoins=" + OnePoundCoins +
                ", FiftyPenceCoins=" + FiftyPenceCoins +
                ", TwentyPenceCoins=" + TwentyPenceCoins +
                ", TenPenceCoins=" + TenPenceCoins +
                ", FivePenceCoins=" + FivePenceCoins +
                ", TwoPenceCoins=" + TwoPenceCoins +
                ", OnePenceCoins=" + OnePenceCoins +
                '}';
    }

    public String ReturnCoins(){
        return "\n\nCOINS : £" + (double)this.ChangeDue/100.0 +"\n\n" +
                "TWO POUND COINS : " + this.TwoPoundCoins +
                "\nONE POUND COINS : " + this.OnePoundCoins +
                "\nFIFTY PENCE COINS : " + this.FiftyPenceCoins+
                "\nTWENTY PENCE COINS : " + this.TwentyPenceCoins +
                "\nTEN PENCE COINS : " + this.TenPenceCoins +
                "\nFIVE PENCE COINS : " + this.FivePenceCoins +
                "\nTWO PENCE COINS : " + this.TwoPenceCoins +
                "\nONE PENCE COINS : " + this.OnePenceCoins +
                "\n\n"
                ;
    }

    public void CalculateChange(int difference){

        int[] NoCoins = {0,0,0,0,0,0,0,0};
        int[] Coins = {200,100,50,20,10,5,2,1};

        this.ChangeDue = difference;
        int remainder = this.ChangeDue % Coins[0];
        //NoCoins[0] = this.ChangeDue / Coins[0];

        if (remainder == 0){
            NoCoins[0] = this.ChangeDue / Coins[0];
        }

        else {
            NoCoins[0] = this.ChangeDue / Coins[0];
            int i = 1;
            do {
                NoCoins[i] = remainder / Coins[i];
                remainder = remainder % Coins[i];
                i++;
            } while (remainder != 0);
        }

        this.TwoPoundCoins = NoCoins[0];
        this.OnePoundCoins = NoCoins[1];
        this.FiftyPenceCoins = NoCoins[2];
        this.TwentyPenceCoins = NoCoins[3];
        this.TenPenceCoins = NoCoins[4];
        this.FivePenceCoins = NoCoins[5];
        this.TwoPenceCoins = NoCoins[6];
        this.OnePenceCoins = NoCoins[7];

        int sum = 0;

        for (int i = 0; i < 8; i++){
            sum += NoCoins[i]*Coins[i];
        }

        this.TwoPoundCoins = NoCoins[0];
    }

    public void CalculateChange(){
        int[] NoCoins = {0,0,0,0,0,0,0,0};
        int[] Coins = {200,100,50,20,10,5,2,1};

        int remainder = this.ChangeDue % Coins[0];
        //NoCoins[0] = this.ChangeDue / Coins[0];

        if (remainder == 0){
            NoCoins[0] = this.ChangeDue / Coins[0];
        }

        else {
            NoCoins[0] = this.ChangeDue / Coins[0];
            int i = 1;
            do {
                NoCoins[i] = remainder / Coins[i];
                remainder = remainder % Coins[i];
                i++;
            } while (remainder != 0);
        }

        this.TwoPoundCoins = NoCoins[0];
        this.OnePoundCoins = NoCoins[1];
        this.FiftyPenceCoins = NoCoins[2];
        this.TwentyPenceCoins = NoCoins[3];
        this.TenPenceCoins = NoCoins[4];
        this.FivePenceCoins = NoCoins[5];
        this.TwoPenceCoins = NoCoins[6];
        this.OnePenceCoins = NoCoins[7];

        int sum = 0;

        for (int i = 0; i < 8; i++){
            sum += NoCoins[i]*Coins[i];
        }

        this.TwoPoundCoins = NoCoins[0];
    }
}//End of Change Class
