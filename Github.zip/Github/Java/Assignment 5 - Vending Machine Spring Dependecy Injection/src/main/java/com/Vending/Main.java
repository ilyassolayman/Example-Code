package com.Vending;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

    public static void main(String[] args) {


        AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext();

        appContext.scan("com.Vending");
        appContext.refresh();

        Controller cont = appContext.getBean("controller", Controller.class);
        cont.run();


    }//End of main class

}
