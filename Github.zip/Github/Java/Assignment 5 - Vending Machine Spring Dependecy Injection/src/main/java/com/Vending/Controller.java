package com.Vending;

import com.Vending.Change;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class Controller {


    private FileIO file;

    @Autowired
    public Controller(FileIO file){

        this.file = file;

    }


    public void run(){


        this.file.ReadFile();



        Items.PrintItems();

        boolean repeat = true;
        do{
            this.file.PrintMenu();

            Scanner in = new Scanner(System.in);
            System.out.println();
            System.out.println("Select an option from the menu : ");
            int choice = Integer.parseInt(in.nextLine());

            switch(choice){

                case 1:
                    VendItem();
                    repeat = false;
                    System.out.println();
                    System.out.println("Thank you for using the vending machine");
                    break;

                case 2:
                    Items.PrintItems();
                    System.out.println();
                    break;
                case 3:
                    System.out.println();
                    System.out.println("Thank you for using the vending machine");
                    repeat = false;
                default:
                    break;
            }


        }while (repeat);

        this.file.WriteFile();
    }

    public void VendItem(){

        Scanner IN = new Scanner(System.in);
        System.out.println();
        System.out.println("You have entered choice 1, to vend an item");
        System.out.println("Please insert some money into the machine, in the form £0.00");

        double money_inputted;
        do {
            System.out.println("Change Inputted : £");
            money_inputted = Double.parseDouble(IN.nextLine());
            System.out.println("YOU HAVE PUT IN £" + money_inputted);
        }while(money_inputted==0);

        int user_item_ID;
        boolean z = true;
        do {
            System.out.println("If you would like to see the items in the vending machine enter 0");
            System.out.println("Please make your item selection by item ID");
            user_item_ID = Integer.parseInt(IN.nextLine());
            if (user_item_ID == 0){
                Items.PrintItems();
            }

            else if (user_item_ID <= Items.AvailableItems.get(Items.AvailableItems.size() -1).getItemID() ){
                z = false;
            }

        }while(z);

        Items Users_item = null;

        for (int i = 0; i < Items.AvailableItems.size(); i++){
            if (Items.AvailableItems.get(i).getItemID() == user_item_ID){
                Users_item = Items.AvailableItems.get(i);
                System.out.println("YOU CHOSE THE " + Users_item.getName().toUpperCase());
                break;
            }
        }

        int money_in = (int) money_inputted*100;
        int difference = money_in - Users_item.getPrice();
        double DIFF;
        double x;

        System.out.println();
        System.out.println();

        boolean cont = true;
        do {
            if (money_in < Users_item.getPrice()) {

                DIFF = (double) (((double)difference)/((double)(-100.0)));
                System.out.println();
                System.out.println("INSUFFICIENT FUNDS");
                System.out.println("Change inputted : £" + (double)money_in/100.0);
                System.out.println("Enter 0 to cancel transaction and get your change back");
                System.out.println("Please enter £" + DIFF);
                System.out.println();
                x = Double.parseDouble(IN.nextLine());

                if (x == 0){
                    System.out.println("RETURNING £" + (double)money_in/100.0 + " in change");
                    Change change = new Change(money_in);
                    change.CalculateChange();
                    System.out.println(change.ReturnCoins());
                    cont = false;
                    break;
                }


                money_in += (int)(x*100);
                difference += (int)(x*100);
            }

            else if (money_in >= Users_item.getPrice()){
                Users_item.vend();


                Change change = new Change(money_in - Users_item.getPrice());
                change.CalculateChange();
                System.out.println(change.ReturnCoins());

                cont = false;
                break;
            }

        }while(cont);
    }
}
