package com.Vending;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;

@Component
public class FileIO {




    public void ReadFile(){

        try {
            BufferedReader br = new BufferedReader(new FileReader("Items.txt"));

            String line;

            while(( line = br.readLine() ) != null){

                String[] elements = line.split(",");

                String item = elements[0];
                int price = Integer.parseInt(elements[1]);
                int stock = Integer.parseInt(elements[2]);


                Items temp = new Items(item, price, stock);
            }

            br.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        System.out.println();
        System.out.println("WELCOME TO THE VENDING MACHINE");
        System.out.println();

    }

    public void WriteFile(){
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("Items.txt"));

            for (int i = 0; i < Items.Collection.size(); i++){
                Items temp = Items.Collection.get(i);
                bw.write(temp.getName() + ",");
                bw.write(temp.getPrice() + ",");
                bw.write(temp.getStock() + "\n");
            }

            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void PrintMenu(){
        System.out.println("1. Vend an item");
        System.out.println("2. Display items and item prices");
        System.out.println("3. Exit vending machine");
    }


}
