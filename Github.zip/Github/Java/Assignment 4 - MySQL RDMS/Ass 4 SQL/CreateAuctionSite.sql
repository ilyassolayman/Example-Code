DROP DATABASE IF EXISTS AuctionSite;

CREATE  DATABASE AuctionSite;

USE AuctionSite;


CREATE TABLE Account(
	AccountTypeID int NOT NULL AUTO_INCREMENT,
    AccountName VarChar(25),
    AccountDescription VarChar(200),
    AccountMonthlySellingLimit int,
    PRIMARY KEY (AccountTypeID)
);
    
CREATE TABLE Users(
	UserID int NOT NULL AUTO_INCREMENT,
    FirstName VarChar(25),
    LastName VarChar(25),
    EmailAddress VarChar(50),
    ContactPhoneNumber int,
    PrimaryAddress VarChar(250),
    AccountTypeID int,
    AccountCreateDateTime DateTime,
    PRIMARY KEY (UserID),
    FOREIGN KEY (AccountTypeID) REFERENCES Account(AccountTypeID)
);




CREATE TABLE Category(
	CategoryID int NOT NULL AUTO_INCREMENT,
    CategoryName VarChar(50),
    CategoryDescription VarChar(250),
    PRIMARY KEY (CategoryID)
);



CREATE TABLE Listings(
	ListingID int NOT NULL AUTO_INCREMENT,
    UserID int,
    CategoryID int,
    BuyNowPrice int,
    ReservePrice int,
    CurrentBid int,
    CurrentUserWinnerID int,
    ListingStart datetime,
    ListingEnd datetime,
    ListingDescription varchar(250),
	PRIMARY KEY (ListingID),
	FOREIGN KEY (UserID) REFERENCES Users(UserID),
	FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
    );


