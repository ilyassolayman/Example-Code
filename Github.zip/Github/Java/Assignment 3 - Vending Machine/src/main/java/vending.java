public interface vending {

    public int vend();

}
